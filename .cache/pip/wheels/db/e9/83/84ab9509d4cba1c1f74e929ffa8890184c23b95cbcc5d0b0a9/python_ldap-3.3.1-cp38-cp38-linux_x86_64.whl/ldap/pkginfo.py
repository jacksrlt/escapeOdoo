# -*- coding: utf-8 -*-
"""
meta attributes for packaging which does not import any dependencies
"""
__version__ = '3.3.1'
__author__ = u'python-ldap project'
__license__ = 'Python style'
